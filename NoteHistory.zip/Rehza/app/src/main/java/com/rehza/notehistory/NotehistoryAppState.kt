package com.rehza.notehistory

object NotehistoryAppState {
    const val WALKTHROUGH_ROUTE = "walkthrough"
    const val HOME_ROUTE = "home"
    const val ADD_HISTORY_ROUTE = "addhistory"
    const val PROFILE_ROUTE = "profile"
}